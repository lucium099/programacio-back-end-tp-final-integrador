<?php 
echo "1)";
echo "Hola mundo"; 
echo "<br>";

echo "2)";
echo "cadena de caracteres";
echo "<br>";

echo "3) ecuaciones. numeros: 5(numero 1) y 99(numero 2) ";
ECHO "<br>";
echo "a)suma 5+99=";

 $numero1 = 5;
 $numero2 = 99;
 $resultado = $numero1 + $numero2; 
echo $resultado;
 echo "<br>";

echo"b)";
echo "resta 5-99=";

 $numero3 = 5;
 $numero4 = 99;
$resultado =$numero3 - $numero4;
echo $resultado;
echo "<br>";

echo"c)";
echo "multiplicación 5*99=";

 $numero3 = 5;
 $numero4 = 99;
$resultado =$numero3 * $numero4;
echo $resultado;
echo "<br>";

echo"d)";
echo "división 5/99=";

 $numero3 = 5;
 $numero4 = 99;
$resultado =$numero3 / $numero4;
echo $resultado;
echo "<br>";

echo"c)";
echo "resto 5%99=";

 $numero3 = 5;
 $numero4 = 99;
$resultado =$numero3 % $numero4;
echo $resultado;

echo "<br>";

echo "4)pasaje de unidad celsius a fahrenheit";
ECHO "<br>";

echo "5)calcular perimetro y areas de rectangulo y circulos";
ECHO "<br>";

?>
